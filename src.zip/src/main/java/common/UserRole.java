package common;

public enum UserRole {
    MEMBER,
    LIBRARIAN,
    AUTHOR,
}
